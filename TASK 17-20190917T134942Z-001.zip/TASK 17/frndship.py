points = 0
names = input('enter the two names: ')

for character in names:
  
  if character in 'friend':
    points += 10
  if character in 'aeiou':
    points += 5

print('your friendship value is :', points)

if points >= 100:
  print('you are amazing!')
