letters = 'abcdefghijklmnopqrstuvwxyz'
new_message = ''
  
message = input('Please enter  message: ')

num = input('Enter a key 1-26: ')
num = int(num)

for character in message:
  if character in letters:
    position = letters.find(character)
    new_position = (position + num) % 26
    new_character = letters[new_position]
    new_message += new_character
  else:
    new_message += character

print('Your new message is: ', new_message)
